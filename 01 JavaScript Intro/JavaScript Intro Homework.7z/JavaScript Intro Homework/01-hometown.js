// JavaScript source code

function myHomeTown() {
    var homeTown = "Plovdiv";
    alert(homeTown);
}