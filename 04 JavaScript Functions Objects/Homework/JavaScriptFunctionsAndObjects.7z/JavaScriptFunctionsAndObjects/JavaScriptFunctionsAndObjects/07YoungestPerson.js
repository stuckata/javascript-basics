﻿function findYoungestPerson(persons) {

	var youngest = 40000;
	var temp = 40000;
	var resultPerson = {};

	for (var person in persons) {
		temp = persons[person].age;
		if (temp < youngest) {
			youngest = temp;
			resultPerson = persons[person];
		}
	}

	return ("The youngest person is " + resultPerson.firstname + " " + resultPerson.lastname);
	
}

console.log(findYoungestPerson([
  { firstname: 'George', lastname: 'Kolev', age: 32 },
  { firstname: 'Bay', lastname: 'Ivan', age: 81 },
  { firstname: 'Baba', lastname: 'Ginka', age: 40 }]
));