﻿function findNthDigit(arr) {

	var n = arr[0];
	var num = arr[1];
	var tempChArr = [];
	var nthDigit = 0;

	if (num < 0) {
		num *= (-1);
	}

	var numStr = num + "";
	numStr = numStr.replace(/[.]/, '');

	if (numStr.length < n) {
		return ("The number doesn’t have " + n + " digits");
	} else {
		for (var ch in numStr) {
			tempChArr.push(numStr[ch]);
		}
		tempChArr.reverse();
		numStr = tempChArr.join('');
		nthDigit = numStr[n - 1];
	}
	return nthDigit;
}

console.log(findNthDigit([1, 6]));
console.log(findNthDigit([2, -55]));
console.log(findNthDigit([6, 923456]));
console.log(findNthDigit([3, 1451.78]));
console.log(findNthDigit([6, 888.88]));