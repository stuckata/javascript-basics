﻿function findLargestBySumOfDigits(nums) {

	if (nums.length == 0) {
		return "undefined";
	}

	var bestSum = 0;
	var tempBest = 0;
	var bestNum = 0;

	for (var n in nums) {

		if ((nums[n] % 1) != 0) {
			return "undefined";
		}

		tempBest = sumDigits(nums[n]);

		if (tempBest > bestSum) {
			bestSum = tempBest;
			bestNum = nums[n];
		}
	}
	return bestNum;
}

function sumDigits(num) {

	if (num < 0) {
		num *= (-1);
	}

	var sum = 0;
	var str = "" + num;

	for (var ch in str) {
		sum += Number(str[ch]);
	}

	return sum;
}

console.log(findLargestBySumOfDigits([5, 10, 15, 111]));
console.log(findLargestBySumOfDigits([33, 44, -99, 0, 20]));
console.log(findLargestBySumOfDigits(['hello']));
console.log(findLargestBySumOfDigits([5, 3.3]));
console.log(findLargestBySumOfDigits([]));