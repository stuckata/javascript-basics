﻿function reverseWordsInString(str) {

	var words = str.split(" ");
	var reversedWords = [];

	for (var w in words) {
		reversedWords.push(reverse(words[w]));
	}

	var result = reversedWords.join(' ');

	return result;
}

function reverse(word) {

	var chars = [];

	for (var ch in word) {
		chars.push(word[ch]);
	}
	chars = chars.reverse();
	var revWord = chars.join('');
	return revWord;
}

console.log(reverseWordsInString("Hello, how are you."));
console.log(reverseWordsInString("Life is pretty good, isn’t it?"));