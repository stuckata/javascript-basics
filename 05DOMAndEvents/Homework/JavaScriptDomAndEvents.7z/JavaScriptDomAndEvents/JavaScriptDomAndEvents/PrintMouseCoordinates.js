﻿function getMouseXY(e) {

	tempX = e.pageX;
	tempY = e.pageY;
	
	if (tempX < 0) {
		tempX = 0;
	}
	if (tempY < 0) {
		tempY = 0;
	}

	document.Show.MouseX.value = tempX;
	document.Show.MouseY.value = tempY;
	document.Show.Time.value = time;
}

document.onmousemove = getMouseXY;

var tempX = 0;
var tempY = 0;
var time = new Date();
