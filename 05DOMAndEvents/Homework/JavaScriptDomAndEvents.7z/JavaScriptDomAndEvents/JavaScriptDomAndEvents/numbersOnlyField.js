﻿function validateInput() {

	var input = document.getElementById('nums');
	var previousValue = input.value.substring(0, input.value.length - 1);

	if (isNaN(input.value)) {
		input.style.backgroundColor = 'red';
		setTimeout(function () { input.style.backgroundColor = 'white' }, 500);
		input.value = previousValue;
	}
}

document.oninput = validateInput;