﻿function hideOddRows(){

	var tableRows = document.getElementsByTagName('tr');

	for (var row in tableRows) {
		if(row % 2 == 0){
			tableRows[row].style.display = 'none';
		}
	}
}

var button = document.getElementById('btnHideOddRows');
button.onclick = hideOddRows;