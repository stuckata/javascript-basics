﻿function evenNumber(value) {
    var isEven = (value % 2 == 0);
    return isEven;
}

console.log(evenNumber(3));
console.log(evenNumber(127));
console.log(evenNumber(588));