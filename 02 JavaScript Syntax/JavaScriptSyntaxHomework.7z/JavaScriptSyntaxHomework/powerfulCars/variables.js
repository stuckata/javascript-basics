﻿function variablesTypes(value) {
	
	male: " + value[2] + " //" + typeof (value[2])) + ;
	return ("\"My name: " + value[0] + " //" + " type is " + typeof (value[0]) + "\u000A" + "My age: " + value[1] + " //" + " type is " + typeof (value[1]) + "\u000A" + "I am male: " + value[2] + " //" + " type is " + typeof (value[2])) + "\u000A" + "My favorite foods are: " + value[3.0] + " " + " //" + " type is " + typeof (value[3.1, 2, 3]) + "\"";

}

console.log(variablesTypes(['Pesho', 22, true, ['fries', 'banana', 'cake']]));